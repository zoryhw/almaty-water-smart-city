import { getToneLabel } from './analysis'

export const CLAUDE_DEFAULTS = {
  endpoint: 'https://api.anthropic.com/v1/messages',
  model: 'claude-sonnet-4-20250514',
  apiKey: '',
  mission: 'Сформируй управленческое решение для штаба, техплан для инженеров и короткое сообщение для жителей.',
}

function inferAudience(mission) {
  const text = mission.toLowerCase()

  if (text.includes('жител') || text.includes('населен')) {
    return 'citizens'
  }

  if (text.includes('инжен') || text.includes('тех')) {
    return 'engineering'
  }

  return 'executive'
}

function buildLocalConfidence(context) {
  const base = 78
  const pressurePenalty = context.analysis.statuses.pressure.tone === 'critical' ? 16 : 6
  const qualityPenalty = context.analysis.statuses.quality.tone === 'critical' ? 14 : 4
  const scenarioPenalty = context.activeScenario === 'crisis' ? 12 : context.activeScenario === 'peak' ? 6 : 0

  return Math.max(42, base - pressurePenalty - qualityPenalty - scenarioPenalty)
}

export function createAquaMindReport(context, mission) {
  const { district, snapshot, analysis, city, activeScenario, viewMode } = context
  const audience = inferAudience(mission)

  const scenarioText =
    activeScenario === 'crisis'
      ? 'кризисный режим с немедленной потребностью в координации'
      : activeScenario === 'peak'
        ? 'режим пиковой нагрузки с риском просадки давления'
        : activeScenario === 'quality'
          ? 'режим санитарного внимания с акцентом на качество воды'
          : 'штатный режим с плановым мониторингом'

  const focusText =
    viewMode === 'response'
      ? 'Приоритет смещён на скорость реагирования и маршрутизацию бригад.'
      : viewMode === 'quality'
        ? 'Приоритет смещён на лабораторный контроль и санитарную устойчивость.'
        : 'Приоритет смещён на гидравлику сети и равномерность подачи.'

  const pressureRisk =
    analysis.statuses.pressure.tone === 'critical'
      ? 'Давление ниже безопасного порога и способно вызвать каскадные ограничения.'
      : analysis.statuses.pressure.tone === 'warning'
        ? 'Давление проседает и требует перераспределения нагрузки.'
        : 'Давление удерживается в рабочем диапазоне.'

  const qualityRisk =
    analysis.statuses.quality.tone === 'critical'
      ? 'Качество воды требует усиленного контроля и подтверждения пробоотбором.'
      : analysis.statuses.quality.tone === 'warning'
        ? 'Качество воды находится на пограничном уровне.'
        : 'Качество воды соответствует рабочим параметрам.'

  const executive =
    analysis.tone === 'critical'
      ? `Район ${district} необходимо перевести в усиленный режим управления. Состояние оценивается как ${getToneLabel(analysis.tone).toLowerCase()}, потому что одновременно проседают ключевые параметры сети.`
      : analysis.tone === 'warning'
        ? `Район ${district} находится под наблюдением. Нужна управляемая коррекция режима, чтобы не допустить перехода в кризис.`
        : `Район ${district} работает устойчиво. Достаточно сохранить текущий режим и подтвердить резерв устойчивости следующими замерами.`

  const engineering =
    analysis.tone === 'critical'
      ? 'Инженерам нужно немедленно проверить насосные узлы, магистральное давление, резервные ветки подачи и выполнить ускоренный обход чувствительных участков.'
      : analysis.tone === 'warning'
        ? 'Инженерам нужно локально перераспределить поток, перепроверить узкие места сети и подтвердить стабильность контрольных точек.'
        : 'Инженерной группе достаточно продолжить профилактический контроль и подтвердить норму по графику.'

  const citizen =
    analysis.tone === 'critical'
      ? `Для жителей: в ${district} районе возможны локальные ограничения подачи воды. Городские службы уже работают над стабилизацией системы.`
      : analysis.tone === 'warning'
        ? `Для жителей: в ${district} районе наблюдаются краткосрочные колебания параметров сети, ситуация находится под контролем.`
        : `Для жителей: водоснабжение в ${district} районе работает в штатном режиме.`

  const recommendations =
    analysis.tone === 'critical'
      ? [
          'Запустить аварийный контур управления давлением и ограничить неключевые ветки.',
          'Подтвердить качество воды ускоренным циклом пробоотбора.',
          'Поднять районный штаб и синхронизировать аварийные бригады.',
        ]
      : analysis.tone === 'warning'
        ? [
            'Сбалансировать поток между насосными станциями района.',
            'Усилить контроль жалоб и сверку телеметрии в ближайшие 2 часа.',
            'Подготовить резервный сценарий без публичной эскалации.',
          ]
        : [
            'Сохранить текущий режим подачи.',
            'Подтвердить показатели на следующем временном окне.',
            'Продолжить штатный мониторинг без аварийных мер.',
          ]

  const confidence = buildLocalConfidence(context)

  const summary = `AquaMind определяет район ${district} как ${getToneLabel(analysis.tone).toLowerCase()}. Сейчас действует ${scenarioText}. ${focusText}`
  const audienceNote =
    audience === 'citizens'
      ? 'Вывод адаптирован под внешнюю коммуникацию.'
      : audience === 'engineering'
        ? 'Вывод адаптирован под инженерную команду.'
        : 'Вывод адаптирован под руководителя.'

  return {
    tone: analysis.tone,
    source: 'aquamind',
    confidence,
    headline: `${district}: ${getToneLabel(analysis.tone)} по версии AquaMind`,
    summary: `${summary} Покрытие ${snapshot.overview.coverage}%, давление ${snapshot.overview.pressure} bar, качество ${snapshot.overview.quality}. ${audienceNote}`,
    executive,
    engineering,
    citizen,
    diagnosis: `${pressureRisk} ${qualityRisk} Покрытие сервиса сейчас ${snapshot.overview.coverage}%, среднее покрытие по городу ${city.averageCoverage}%, среднее качество по городу ${city.averageQuality}.`,
    recommendations,
  }
}

function buildClaudeSystemPrompt() {
  return [
    'You are AquaMind, an AI command analyst for an urban water supply dashboard.',
    'Return only valid JSON in Russian.',
    'Your JSON must have the keys: headline, summary, diagnosis, executive, engineering, citizen, recommendations, tone, confidence.',
    'recommendations must be an array of short strings.',
    'tone must be one of: normal, warning, critical.',
    'confidence must be an integer from 0 to 100.',
  ].join(' ')
}

function buildClaudeUserPrompt(context, mission) {
  const { district, snapshot, analysis, city, activeScenario, viewMode } = context

  return `
Контекст smart city dashboard:
- Район: ${district}
- Сценарий: ${activeScenario}
- Режим обзора: ${viewMode}
- Статус: ${getToneLabel(analysis.tone)}
- Уровень воды: ${snapshot.overview.waterLevel}%
- Давление: ${snapshot.overview.pressure} bar
- Инциденты: ${snapshot.overview.incidents}
- Качество воды: ${snapshot.overview.quality}
- Покрытие сервиса: ${snapshot.overview.coverage}%
- Среднее покрытие по городу: ${city.averageCoverage}%
- Среднее давление по городу: ${city.averagePressure} bar
- Всего инцидентов по городу: ${city.totalIncidents}

Задача:
${mission}

Сформируй:
1. diagnosis
2. executive
3. engineering
4. citizen
5. recommendations

Тон должен быть кратким, продуктовым и пригодным для реального городского штаба.
`.trim()
}

function parseJsonCandidate(text) {
  try {
    return JSON.parse(text)
  } catch {
    const start = text.indexOf('{')
    const end = text.lastIndexOf('}')
    if (start === -1 || end === -1 || end <= start) {
      return null
    }

    try {
      return JSON.parse(text.slice(start, end + 1))
    } catch {
      return null
    }
  }
}

function normalizeClaudePayload(payload, fallbackTone) {
  if (!payload || typeof payload !== 'object') {
    return null
  }

  return {
    headline: payload.headline || 'Claude ответил без headline',
    summary: payload.summary || 'Claude не сформировал summary.',
    diagnosis: payload.diagnosis || 'Диагноз не был сформирован.',
    executive: payload.executive || 'Управленческий вывод отсутствует.',
    engineering: payload.engineering || 'Инженерный вывод отсутствует.',
    citizen: payload.citizen || 'Сообщение для жителей отсутствует.',
    recommendations: Array.isArray(payload.recommendations)
      ? payload.recommendations.slice(0, 4)
      : ['Проверить структуру JSON в ответе Claude.'],
    tone: payload.tone || fallbackTone,
    confidence: Number.isFinite(payload.confidence) ? payload.confidence : 74,
    source: 'claude',
  }
}

function extractClaudeText(data) {
  if (Array.isArray(data?.content)) {
    return data.content
      .filter((part) => part?.type === 'text')
      .map((part) => part.text)
      .join('\n')
  }

  if (typeof data?.completion === 'string') {
    return data.completion
  }

  return ''
}

export async function requestClaudeReport(context, config) {
  const endpoint = config.endpoint || CLAUDE_DEFAULTS.endpoint
  const model = config.model || CLAUDE_DEFAULTS.model

  if (!config.apiKey) {
    throw new Error('Для Claude-режима нужен Anthropic API key.')
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': config.apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model,
      max_tokens: 900,
      system: buildClaudeSystemPrompt(),
      messages: [
        {
          role: 'user',
          content: buildClaudeUserPrompt(context, config.mission),
        },
      ],
    }),
  })

  if (!response.ok) {
    const reason = await response.text()
    throw new Error(`Claude API error ${response.status}: ${reason || 'unknown error'}`)
  }

  const data = await response.json()
  const text = extractClaudeText(data)

  if (!text) {
    throw new Error('Claude API вернул пустой content.')
  }

  const parsed = parseJsonCandidate(text)
  const normalized = normalizeClaudePayload(parsed, context.analysis.tone)

  if (normalized) {
    return normalized
  }

  return {
    headline: 'Claude вернул свободный текст',
    summary: text.slice(0, 220),
    diagnosis: text,
    executive: 'Ответ не был структурирован в JSON, поэтому показан как текст.',
    engineering: 'Проверь системный prompt и формат endpoint.',
    citizen: 'Для production лучше использовать proxy и валидировать JSON на сервере.',
    recommendations: ['Проверить формат JSON.', 'Повторить запрос.', 'Сверить модель и endpoint.'],
    tone: context.analysis.tone,
    confidence: 62,
    source: 'claude',
  }
}
