import { useEffect, useMemo, useState } from 'react'
import {
  CircleMarker,
  MapContainer,
  Polyline,
  Popup,
  TileLayer,
  Tooltip,
  useMap,
} from 'react-leaflet'
import { almatyMapConfig, districtOrder } from '../data/mockData'
import { formatNumber, getToneLabel } from '../utils/analysis'

const toneColors = {
  normal: '#35c8a6',
  warning: '#ffbf62',
  critical: '#ff7b86',
}

const hotspotLabels = {
  pressure: 'Давление',
  quality: 'Качество',
  incident: 'Инцидент',
  coverage: 'Покрытие',
  consumption: 'Нагрузка',
  service: 'Сервис',
}

function FocusController({ center, zoom }) {
  const map = useMap()

  useEffect(() => {
    map.flyTo(center, zoom, {
      duration: 1.1,
    })
  }, [center, zoom, map])

  return null
}

export function AlmatyMap({
  selectedDistrict,
  districtStates,
  districtSnapshots,
  districtActions,
  onSelectDistrict,
}) {
  const [focusMode, setFocusMode] = useState('selected')
  const [layers, setLayers] = useState({
    nodes: true,
    routes: true,
    incidents: true,
  })

  const selectedMap = almatyMapConfig.districts[selectedDistrict]
  const selectedSnapshot = districtSnapshots[selectedDistrict]
  const activeInterventions = Object.values(districtActions[selectedDistrict] || {}).filter(Boolean).length

  const mapCenter = focusMode === 'city' ? almatyMapConfig.center : selectedMap.position
  const mapZoom = focusMode === 'city' ? almatyMapConfig.zoom : 12.5

  const routeLines = useMemo(() => {
    return districtOrder.map((district) => {
      const districtMap = almatyMapConfig.districts[district]
      const node = almatyMapConfig.nodes.find((item) => item.id === districtMap.source)

      return {
        district,
        tone: districtStates[district].tone,
        positions: [node.position, districtMap.position],
      }
    })
  }, [districtStates])

  const hotspots = useMemo(() => {
    return districtOrder.flatMap((district) => {
      const districtMap = almatyMapConfig.districts[district]
      const districtTone = districtStates[district].tone

      return districtMap.hotspots.map((hotspot) => ({
        ...hotspot,
        district,
        severity: districtTone === 'critical' ? 'critical' : hotspot.severity,
      }))
    })
  }, [districtStates])

  const toggleLayer = (key) => {
    setLayers((current) => ({
      ...current,
      [key]: !current[key],
    }))
  }

  return (
    <section className="almaty-map-panel panel-surface anim delay-7">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Live city map</p>
          <h3>Интерактивная карта Алматы</h3>
        </div>
        <span className="section-note">Клик по району на карте синхронизирует все панели и AI-анализ</span>
      </div>

      <div className="map-toolbar">
        <div className="map-focus-switch">
          <button
            type="button"
            className={focusMode === 'selected' ? 'active' : ''}
            onClick={() => setFocusMode('selected')}
          >
            Выбранный район
          </button>
          <button
            type="button"
            className={focusMode === 'city' ? 'active' : ''}
            onClick={() => setFocusMode('city')}
          >
            Весь город
          </button>
        </div>

        <div className="map-layer-toggles">
          <button type="button" className={layers.nodes ? 'active' : ''} onClick={() => toggleLayer('nodes')}>
            Узлы
          </button>
          <button type="button" className={layers.routes ? 'active' : ''} onClick={() => toggleLayer('routes')}>
            Маршруты
          </button>
          <button
            type="button"
            className={layers.incidents ? 'active' : ''}
            onClick={() => toggleLayer('incidents')}
          >
            Инциденты
          </button>
        </div>
      </div>

      <div className="map-layout">
        <div className="map-shell">
          <MapContainer
            center={almatyMapConfig.center}
            zoom={almatyMapConfig.zoom}
            scrollWheelZoom
            className="almaty-leaflet-map"
          >
            <FocusController center={mapCenter} zoom={mapZoom} />

            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            {layers.routes
              ? routeLines.map((route) => (
                  <Polyline
                    key={route.district}
                    positions={route.positions}
                    pathOptions={{
                      color: toneColors[route.tone],
                      weight: selectedDistrict === route.district ? 5 : 3,
                      opacity: selectedDistrict === route.district ? 0.9 : 0.45,
                      dashArray: selectedDistrict === route.district ? '10 8' : '6 8',
                    }}
                  />
                ))
              : null}

            {layers.nodes
              ? almatyMapConfig.nodes.map((node) => (
                  <CircleMarker
                    key={node.id}
                    center={node.position}
                    radius={8}
                    pathOptions={{
                      color: '#1877d6',
                      fillColor: '#3ca0f6',
                      fillOpacity: 0.9,
                      weight: 2,
                    }}
                  >
                    <Tooltip>{node.title}</Tooltip>
                  </CircleMarker>
                ))
              : null}

            {districtOrder.map((district) => {
              const districtMap = almatyMapConfig.districts[district]
              const districtState = districtStates[district]
              const snapshot = districtSnapshots[district]
              const actionCount = Object.values(districtActions[district] || {}).filter(Boolean).length

              return (
                <CircleMarker
                  key={district}
                  center={districtMap.position}
                  radius={selectedDistrict === district ? 18 : 13}
                  eventHandlers={{
                    click: () => onSelectDistrict(district),
                  }}
                  pathOptions={{
                    color: toneColors[districtState.tone],
                    fillColor: toneColors[districtState.tone],
                    fillOpacity: selectedDistrict === district ? 0.34 : 0.18,
                    weight: selectedDistrict === district ? 4 : 3,
                  }}
                >
                  <Tooltip direction="top" offset={[0, -10]}>
                    {district}
                  </Tooltip>
                  <Popup>
                    <div className="map-popup">
                      <strong>{district}</strong>
                      <p>{getToneLabel(districtState.tone)}</p>
                      <div className="map-popup-grid">
                        <span>Давление: {snapshot.overview.pressure} bar</span>
                        <span>Качество: {snapshot.overview.quality}</span>
                        <span>Покрытие: {snapshot.overview.coverage}%</span>
                        <span>Активные меры: {actionCount}</span>
                      </div>
                    </div>
                  </Popup>
                </CircleMarker>
              )
            })}

            {layers.incidents
              ? hotspots.map((hotspot) => (
                  <CircleMarker
                    key={hotspot.id}
                    center={hotspot.position}
                    radius={hotspot.severity === 'critical' ? 8 : 6}
                    pathOptions={{
                      color: toneColors[hotspot.severity],
                      fillColor: toneColors[hotspot.severity],
                      fillOpacity: 0.92,
                      weight: 2,
                    }}
                  >
                    <Popup>
                      <div className="map-popup">
                        <strong>{hotspot.title}</strong>
                        <p>{hotspot.district}</p>
                        <div className="map-popup-grid">
                          <span>Тип: {hotspotLabels[hotspot.kind] || hotspot.kind}</span>
                          <span>Статус: {getToneLabel(hotspot.severity)}</span>
                        </div>
                      </div>
                    </Popup>
                  </CircleMarker>
                ))
              : null}
          </MapContainer>
        </div>

        <aside className="map-sidecard">
          <div className="map-sidecard-head">
            <strong>{selectedDistrict}</strong>
            <span>{getToneLabel(districtStates[selectedDistrict].tone)}</span>
          </div>

          <div className="map-sidecard-grid">
            <article>
              <span>Потребление</span>
              <strong>{formatNumber(selectedSnapshot.overview.consumption)} м³</strong>
            </article>
            <article>
              <span>Жалобы</span>
              <strong>{selectedSnapshot.overview.complaints}</strong>
            </article>
            <article>
              <span>Pressure</span>
              <strong>{selectedSnapshot.overview.pressure} bar</strong>
            </article>
            <article>
              <span>Interventions</span>
              <strong>{activeInterventions}</strong>
            </article>
          </div>

          <div className="map-legend">
            <div>
              <span className="legend-dot tone-normal" />
              <small>Стабильно</small>
            </div>
            <div>
              <span className="legend-dot tone-warning" />
              <small>Под риском</small>
            </div>
            <div>
              <span className="legend-dot tone-critical" />
              <small>Критично</small>
            </div>
          </div>

          <div className="map-tips">
            <p>Кликни по району на карте, чтобы пересобрать аналитические блоки.</p>
            <p>Включай слои узлов, маршрутов и инцидентов для разных режимов просмотра.</p>
          </div>
        </aside>
      </div>
    </section>
  )
}
