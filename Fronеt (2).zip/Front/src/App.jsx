import { useEffect, useMemo, useState } from 'react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { AlmatyMap } from './components/AlmatyMap'
import { AquaMindStudio } from './components/AquaMindStudio'
import { OperationsConsole } from './components/OperationsConsole'
import { districtOrder, districts, scenarioProfiles } from './data/mockData'
import {
  analyzeSnapshot,
  buildAiBriefing,
  formatNumber,
  getCitySnapshot,
  getDistrictScenarioSnapshot,
  getToneLabel,
} from './utils/analysis'
import {
  applyOperationalActions,
  getSuggestedOperations,
  makeOperationLogEntry,
} from './utils/operations'

const pages = [
  { id: 'overview', label: 'Обзор' },
  { id: 'map', label: 'Карта' },
  { id: 'operations', label: 'Операции' },
  { id: 'analytics', label: 'Аналитика' },
  { id: 'ai', label: 'AI центр' },
]

const scenarioOrder = ['baseline', 'morning', 'repair', 'quality', 'storm']
const clamp = (value, min, max) => Math.min(Math.max(value, min), max)

const chartTooltip = {
  contentStyle: {
    background: 'rgba(255,255,255,0.96)',
    border: '1px solid #d9e4ef',
    borderRadius: '14px',
    boxShadow: '0 10px 24px rgba(58, 104, 144, 0.08)',
  },
  labelStyle: {
    color: '#28465d',
    fontWeight: 600,
  },
}

function getInitialPage() {
  if (typeof window === 'undefined') {
    return 'overview'
  }

  const page = window.location.hash.replace('#', '')
  return pages.some((item) => item.id === page) ? page : 'overview'
}

function normalizeAiScenario(scenario) {
  if (scenario === 'storm') return 'crisis'
  if (scenario === 'morning') return 'peak'
  return scenario
}

function AppHeader({ activePage, onPageChange, city, currentTime }) {
  const timeLabel = new Intl.DateTimeFormat('ru-RU', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(currentTime)

  return (
    <header className="split-header panel-surface">
      <div>
        <p className="eyebrow">Smart City Water</p>
        <h1>Almaty Water Control</h1>
      </div>

      <nav className="split-nav">
        {pages.map((page) => (
          <button
            key={page.id}
            type="button"
            className={activePage === page.id ? 'active' : ''}
            onClick={() => onPageChange(page.id)}
          >
            {page.label}
          </button>
        ))}
      </nav>

      <div className="split-header-meta">
        <div>
          <span>Resilience</span>
          <strong>{city.cityResilience}</strong>
        </div>
        <div>
          <span>Время</span>
          <strong>{timeLabel}</strong>
        </div>
      </div>
    </header>
  )
}

function SidePanel({
  selectedDistrict,
  onSelectDistrict,
  activeScenario,
  onScenarioChange,
  districtStates,
  city,
}) {
  return (
    <aside className="split-sidebar panel-surface">
      <section className="sidebar-block">
        <p className="eyebrow">Город</p>
        <div className="sidebar-city-grid">
          <article>
            <span>Покрытие</span>
            <strong>{city.averageCoverage}%</strong>
          </article>
          <article>
            <span>Качество</span>
            <strong>{city.averageQuality}</strong>
          </article>
          <article>
            <span>Давление</span>
            <strong>{city.averagePressure} bar</strong>
          </article>
          <article>
            <span>Инциденты</span>
            <strong>{city.totalIncidents}</strong>
          </article>
        </div>
      </section>

      <section className="sidebar-block">
        <p className="eyebrow">Сценарий</p>
        <div className="sidebar-scenarios">
          {scenarioOrder.map((key) => (
            <button
              key={key}
              type="button"
              className={activeScenario === key ? 'active' : ''}
              onClick={() => onScenarioChange(key)}
            >
              {scenarioProfiles[key].title}
            </button>
          ))}
        </div>
      </section>

      <section className="sidebar-block">
        <p className="eyebrow">Районы</p>
        <div className="sidebar-districts">
          {districtOrder.map((district) => (
            <button
              key={district}
              type="button"
              className={selectedDistrict === district ? 'active' : ''}
              onClick={() => onSelectDistrict(district)}
            >
              <div>
                <strong>{district}</strong>
                <span>{districtStates[district].zone}</span>
              </div>
              <small>{districtStates[district].resilience}</small>
            </button>
          ))}
        </div>
      </section>
    </aside>
  )
}

function OverviewPage({ district, snapshot, analysis, briefing, city }) {
  const kpis = [
    { label: 'Уровень воды', value: `${snapshot.overview.waterLevel}%` },
    { label: 'Давление', value: `${snapshot.overview.pressure} bar` },
    { label: 'Качество', value: `${snapshot.overview.quality}` },
    { label: 'ETA', value: `${snapshot.overview.responseEta} мин` },
  ]

  return (
    <section className="page-stack">
      <div className="page-heading">
        <div>
          <p className="eyebrow">Обзор района</p>
          <h2>{district}</h2>
        </div>
        <span className={`mini-tone tone-${analysis.tone}`}>{getToneLabel(analysis.tone)}</span>
      </div>

      <div className="page-grid page-grid-overview">
        <article className="content-card panel-surface">
          <p className="eyebrow">Сводка</p>
          <h3>{briefing.headline}</h3>
          <p className="body-text">{briefing.summary}</p>
          <div className="kpi-grid-simple">
            {kpis.map((item) => (
              <div key={item.label}>
                <span>{item.label}</span>
                <strong>{item.value}</strong>
              </div>
            ))}
          </div>
        </article>

        <article className="content-card panel-surface">
          <p className="eyebrow">Директива</p>
          <h3>Что делать сейчас</h3>
          <ul className="simple-list">
            {briefing.recommendations.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </article>
      </div>

      <div className="page-grid page-grid-overview">
        <article className="content-card panel-surface">
          <p className="eyebrow">События</p>
          <div className="compact-events">
            {briefing.events.map((event) => (
              <div key={`${event.time}-${event.title}`} className="compact-event">
                <strong>{event.time}</strong>
                <div>
                  <span>{event.title}</span>
                  <p>{event.description}</p>
                </div>
              </div>
            ))}
          </div>
        </article>

        <article className="content-card panel-surface">
          <p className="eyebrow">Городской контекст</p>
          <div className="kpi-grid-simple">
            <div>
              <span>Резерв воды</span>
              <strong>{city.waterReserve}%</strong>
            </div>
            <div>
              <span>Нагрузка</span>
              <strong>{city.demandLoad}%</strong>
            </div>
            <div>
              <span>Жалобы</span>
              <strong>{city.totalComplaints}</strong>
            </div>
            <div>
              <span>Нестабильные районы</span>
              <strong>{city.unstableDistricts}</strong>
            </div>
          </div>
        </article>
      </div>
    </section>
  )
}

function AnalyticsPage({ snapshot, comparison }) {
  return (
    <section className="page-stack">
      <div className="page-heading">
        <div>
          <p className="eyebrow">Аналитика</p>
          <h2>Динамика и сравнение</h2>
        </div>
      </div>

      <div className="page-grid page-grid-analytics">
        <article className="content-card panel-surface">
          <p className="eyebrow">Потребление</p>
          <div className="simple-chart">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={snapshot.trends.consumption}>
                <defs>
                  <linearGradient id="miniFlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#4caef7" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#4caef7" stopOpacity={0.04} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="4 4" stroke="#e2ebf2" />
                <XAxis dataKey="time" stroke="#7690a4" />
                <YAxis stroke="#7690a4" />
                <Tooltip {...chartTooltip} />
                <Area type="monotone" dataKey="value" stroke="#3299eb" strokeWidth={2.5} fill="url(#miniFlow)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </article>

        <article className="content-card panel-surface">
          <p className="eyebrow">Давление</p>
          <div className="simple-chart">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={snapshot.trends.pressure}>
                <CartesianGrid strokeDasharray="4 4" stroke="#e2ebf2" />
                <XAxis dataKey="time" stroke="#7690a4" />
                <YAxis stroke="#7690a4" />
                <Tooltip {...chartTooltip} />
                <Line type="monotone" dataKey="value" stroke="#7f8dff" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </article>

        <article className="content-card panel-surface">
          <p className="eyebrow">Качество</p>
          <div className="simple-chart">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={snapshot.trends.quality}>
                <CartesianGrid strokeDasharray="4 4" stroke="#e2ebf2" />
                <XAxis dataKey="time" stroke="#7690a4" />
                <YAxis stroke="#7690a4" />
                <Tooltip {...chartTooltip} />
                <Line type="monotone" dataKey="value" stroke="#35c8a6" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </article>

        <article className="content-card panel-surface">
          <p className="eyebrow">Районы</p>
          <div className="simple-chart">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={comparison}>
                <CartesianGrid strokeDasharray="4 4" stroke="#e2ebf2" />
                <XAxis dataKey="name" stroke="#7690a4" />
                <YAxis stroke="#7690a4" />
                <Tooltip {...chartTooltip} />
                <Bar dataKey="risk" radius={[10, 10, 0, 0]}>
                  {comparison.map((entry) => (
                    <Cell
                      key={entry.name}
                      fill={entry.tone === 'critical' ? '#ff7b86' : entry.tone === 'warning' ? '#ffbf62' : '#4caef7'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </article>
      </div>
    </section>
  )
}

function App() {
  const [activePage, setActivePage] = useState(getInitialPage)
  const [selectedDistrict, setSelectedDistrict] = useState('Бостандыкский')
  const [activeScenario, setActiveScenario] = useState('baseline')
  const [districtActions, setDistrictActions] = useState({})
  const [operationsLog, setOperationsLog] = useState([])
  const [currentTime, setCurrentTime] = useState(() => new Date())

  useEffect(() => {
    const syncPage = () => setActivePage(getInitialPage())
    window.addEventListener('hashchange', syncPage)
    if (!window.location.hash) {
      window.location.hash = 'overview'
    }

    return () => window.removeEventListener('hashchange', syncPage)
  }, [])

  useEffect(() => {
    const timer = window.setInterval(() => setCurrentTime(new Date()), 1000)
    return () => window.clearInterval(timer)
  }, [])

  const districtSnapshots = useMemo(() => {
    return districtOrder.reduce((acc, district) => {
      const scenarioSnapshot = getDistrictScenarioSnapshot(districts[district], scenarioProfiles[activeScenario])
      acc[district] = applyOperationalActions(scenarioSnapshot, districtActions[district])
      return acc
    }, {})
  }, [activeScenario, districtActions])

  const selectedSnapshot = districtSnapshots[selectedDistrict]
  const analysis = useMemo(() => analyzeSnapshot(selectedSnapshot), [selectedSnapshot])
  const city = useMemo(() => getCitySnapshot(districtSnapshots), [districtSnapshots])
  const briefing = useMemo(
    () => buildAiBriefing(selectedDistrict, selectedSnapshot, analysis, activePage === 'ai' ? 'ai' : activePage, activeScenario),
    [selectedDistrict, selectedSnapshot, analysis, activePage, activeScenario],
  )

  const districtStates = useMemo(
    () =>
      districtOrder.reduce((acc, district) => {
        const snapshot = districtSnapshots[district]
        const current = analyzeSnapshot(snapshot)
        acc[district] = {
          tone: current.tone,
          resilience: current.resilience,
          coverage: snapshot.overview.coverage,
          quality: snapshot.overview.quality,
          zone: snapshot.meta.zone,
        }
        return acc
      }, {}),
    [districtSnapshots],
  )

  const comparison = useMemo(
    () =>
      districtOrder.map((district) => {
        const current = analyzeSnapshot(districtSnapshots[district])
        return {
          name: district.replace('ский', ''),
          risk: current.riskScore,
          tone: current.tone,
        }
      }),
    [districtSnapshots],
  )

  const aiContext = useMemo(
    () => ({
      district: selectedDistrict,
      snapshot: selectedSnapshot,
      analysis,
      city,
      viewMode: activePage === 'operations' ? 'response' : activePage === 'map' ? 'network' : activePage,
      activeScenario: normalizeAiScenario(activeScenario),
      briefing,
    }),
    [selectedDistrict, selectedSnapshot, analysis, city, activePage, activeScenario, briefing],
  )

  const handlePageChange = (page) => {
    window.location.hash = page
    setActivePage(page)
  }

  const handleToggleAction = (actionId) => {
    const nextEnabled = !districtActions[selectedDistrict]?.[actionId]
    setDistrictActions((current) => ({
      ...current,
      [selectedDistrict]: {
        ...current[selectedDistrict],
        [actionId]: nextEnabled,
      },
    }))
    setOperationsLog((current) => [makeOperationLogEntry(selectedDistrict, actionId, nextEnabled), ...current].slice(0, 8))
  }

  const handleRunAiPlan = () => {
    const suggested = getSuggestedOperations(analysis)
    const currentActions = districtActions[selectedDistrict] || {}

    setDistrictActions((current) => ({
      ...current,
      [selectedDistrict]: suggested.reduce(
        (acc, actionId) => ({ ...acc, [actionId]: true }),
        { ...current[selectedDistrict] },
      ),
    }))

    setOperationsLog((current) => [
      ...suggested
        .filter((actionId) => !currentActions[actionId])
        .map((actionId) => makeOperationLogEntry(selectedDistrict, actionId, true)),
      ...current,
    ].slice(0, 8))
  }

  const handleClearActions = () => {
    const activeActionIds = Object.entries(districtActions[selectedDistrict] || {})
      .filter(([, enabled]) => enabled)
      .map(([actionId]) => actionId)

    if (!activeActionIds.length) {
      return
    }

    setDistrictActions((current) => ({ ...current, [selectedDistrict]: {} }))
    setOperationsLog((current) => [
      ...activeActionIds.map((actionId) => makeOperationLogEntry(selectedDistrict, actionId, false)),
      ...current,
    ].slice(0, 8))
  }

  return (
    <div className="app-shell-v5 minimal-mode split-app-shell">
      <main className="split-layout">
        <SidePanel
          selectedDistrict={selectedDistrict}
          onSelectDistrict={setSelectedDistrict}
          activeScenario={activeScenario}
          onScenarioChange={setActiveScenario}
          districtStates={districtStates}
          city={city}
        />

        <section className="split-main">
          <AppHeader
            activePage={activePage}
            onPageChange={handlePageChange}
            city={city}
            currentTime={currentTime}
          />

          {activePage === 'overview' ? (
            <OverviewPage
              district={selectedDistrict}
              snapshot={selectedSnapshot}
              analysis={analysis}
              briefing={briefing}
              city={city}
            />
          ) : null}

          {activePage === 'map' ? (
            <section className="page-stack">
              <div className="page-heading">
                <div>
                  <p className="eyebrow">Карта</p>
                  <h2>Алматы</h2>
                </div>
              </div>
              <AlmatyMap
                selectedDistrict={selectedDistrict}
                districtStates={districtStates}
                districtSnapshots={districtSnapshots}
                districtActions={districtActions}
                onSelectDistrict={setSelectedDistrict}
              />
            </section>
          ) : null}

          {activePage === 'operations' ? (
            <section className="page-stack">
              <div className="page-heading">
                <div>
                  <p className="eyebrow">Операции</p>
                  <h2>Пульт района</h2>
                </div>
              </div>
              <div className="page-grid page-grid-overview">
                <OperationsConsole
                  selectedDistrict={selectedDistrict}
                  snapshot={selectedSnapshot}
                  analysis={analysis}
                  actions={districtActions[selectedDistrict] || {}}
                  operationsLog={operationsLog}
                  onToggleAction={handleToggleAction}
                  onRunAiPlan={handleRunAiPlan}
                  onClearActions={handleClearActions}
                />
                <article className="content-card panel-surface">
                  <p className="eyebrow">Контекст</p>
                  <h3>{selectedDistrict}</h3>
                  <ul className="simple-list">
                    {briefing.watchlist.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </article>
              </div>
            </section>
          ) : null}

          {activePage === 'analytics' ? (
            <AnalyticsPage snapshot={selectedSnapshot} comparison={comparison} />
          ) : null}

          {activePage === 'ai' ? (
            <section className="page-stack">
              <div className="page-heading">
                <div>
                  <p className="eyebrow">AI центр</p>
                  <h2>Управленческий ассистент</h2>
                </div>
              </div>
              <AquaMindStudio context={aiContext} />
            </section>
          ) : null}
        </section>
      </main>
    </div>
  )
}

export default App
